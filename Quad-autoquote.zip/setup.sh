#!/usr/bin/env bash
# Environment setup: run once per fresh environment, before quad/run.py.
set -euo pipefail
cd "$(dirname "$0")"
python3 -m pip install -q -r requirements.txt
python3 -m playwright install --with-deps chromium
