"""Scheduled Quad spot-quote run.

Usage:
    python3 -m quad.run            # live: saves rates
    python3 -m quad.run --dry-run  # computes rates, saves nothing
    python3 -m quad.run --price-all  # test: price every load on the board, save nothing
"""
import argparse
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

from . import quadblu
from .browser import browser_context
from .errors import StopRun
from .nexus import Nexus
from .pricing import Decision, parse_dt, price_load

NY = ZoneInfo("America/New_York")


def research(nx, load):
    o_city, o_st, f_city, f_st = load["origin_city"], load["origin_state"], load["final_city"], load["final_state"]
    state = nx.dest_state_history(o_st, f_st)
    lane = [h for h in state if h["origin"]["place"].upper() == o_city.upper()
            and h["destination"]["place"].upper() == f_city.upper()]
    nearby = nx.nearby_history(o_st, load["final_zip"])
    try:
        lp = nx.lane_pricing(o_city.title(), o_st, load["origin_zip"], f_city.title(), f_st,
                             load["final_zip"], parse_dt(load["pickup"]).date().isoformat())
    except Exception as e:  # lane pricing outage shouldn't kill the run
        lp = None
        print(f"  lane pricing failed for {load['trip_id']}: {e}", file=sys.stderr)
    return lane, state, nearby, lp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--price-all", action="store_true",
                    help="test mode: price every board load (incl. already quoted); implies --dry-run")
    args = ap.parse_args()
    args.dry_run = args.dry_run or args.price_all
    today = datetime.now(NY).date()
    results = []

    try:
        with browser_context() as ctx:
            qb = ctx.new_page()
            quadblu.login(qb)
            board = quadblu.load_board(qb)
            todo = board if args.price_all else [r for r in board if r["current_rate"] == 0.0]
            if not todo:
                print("No new loads to quote")
                return 0

            nx = Nexus.login(ctx)
            for load in todo:
                tid = load["trip_id"]
                lane_label = f"{load['origin_city']}, {load['origin_state']} -> {load['final_city']}, {load['final_state']}"
                try:
                    if parse_dt(load["pickup"]).date() == today:
                        dec = Decision("skip", notes=["same-day pickup"])
                    else:
                        dec = price_load(load, *research(nx, load), today=today)
                    status = dec.action
                    if dec.action == "quote":
                        if args.dry_run:
                            status = "dry-run"
                        else:
                            ok, msg = quadblu.save_rate(qb, tid, dec.rate)
                            status = "quoted" if ok else "flagged"
                            if not ok:
                                dec.flags.append(msg)
                except Exception as e:
                    dec, status = Decision("flag", flags=[f"error: {e}"]), "flagged"
                if args.price_all and load["current_rate"]:
                    dec.notes.insert(0, f"(currently quoted ${load['current_rate']:,.0f})")
                results.append((tid, lane_label, load["mode_service"], load["equipment"], status, dec))
    except StopRun as e:
        print(f"RUN STOPPED: {e}")
        return 2

    print_summary(results)
    return 0


def print_summary(results):
    print("| Trip | Lane | Mode / Equip | Result | Rate | Rationale / Issue |")
    print("|---|---|---|---|---|---|")
    for tid, lane, mode, equip, status, dec in results:
        rate = f"${dec.rate:,.2f}" if dec.rate else "-"
        why = "; ".join(dec.notes + [f"FLAG: {f}" for f in dec.flags])
        print(f"| {tid} | {lane} | {mode} / {equip} | {status} | {rate} | {why} |")


if __name__ == "__main__":
    sys.exit(main())
