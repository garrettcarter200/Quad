"""Pricing rules for Quad spot loads. Returns a Decision (quote / skip / flag)."""
import hashlib
import math
from dataclasses import dataclass, field
from datetime import datetime

SOUTH = {"WV", "VA", "NC", "SC", "GA", "FL", "AL", "MS", "TN", "KY", "LA", "AR"}
REMOTE_STATES = {"MT", "ND"}
BORDER_CITIES = {"EL PASO", "LAREDO", "MCALLEN"}
BORDER_ZIP3 = {"798", "799", "780", "785"}
NYC_LI_ZIP3 = {str(z) for z in range(100, 105)} | {str(z) for z in range(110, 120)}
REDDING_ZIP3 = {"960"}
RENO_ZIP3 = {"894", "895", "897"}
WEST_COAST = {"CA", "WA", "OR"}
SOLO_MPH, SOLO_DRIVE_HRS, SOLO_BREAK_HRS = 50, 11, 10
BAD_ENDINGS = {0, 25, 50, 75}
EXTRA_MILE_RPM = 3.0


@dataclass
class Decision:
    action: str  # "quote" | "skip" | "flag"
    rate: float | None = None
    notes: list = field(default_factory=list)
    flags: list = field(default_factory=list)


def parse_dt(s):
    return datetime.strptime(s.strip(), "%m/%d/%Y %H:%M")


def recency_weighted_avg(loads):
    """Most recent loads weigh most (1, 1/2, 1/3, ...); list is newest-first."""
    if not loads:
        return None
    w = [1 / (i + 1) for i in range(len(loads))]
    return sum(l["customerTotalRate"] * wi for l, wi in zip(loads, w)) / sum(w)


def rpm_avg(loads):
    pts = [(l["customerTotalRate"] / l["customer_miles"]) for l in loads if (l.get("customer_miles") or 0) > 50]
    if not pts:
        return None
    w = [1 / (i + 1) for i in range(len(pts))]
    return sum(p * wi for p, wi in zip(pts, w)) / sum(w)


def market_midpoint(lp, miles):
    """All-in market midpoint ($) from Greenscreens + DAT best-fit medians.

    Market $/mi applies to the direct lane distance; extra routed miles from
    stops/backtracking are added at a capped per-mile rate.
    """
    if not lp or lp.get("status") != "COMPLETED":
        return None, "lane pricing unavailable"
    best = {r["source"]: r for r in lp["rates"] if r["window"] == "BEST_FIT" and r["areaType"] == "MARKET"}
    fuel = lp.get("fuelRate") or 0
    rpms, parts = [], []
    if "GREENSCREENS" in best:
        g = best["GREENSCREENS"]["ratePerMile"]["median"]
        rpms.append(g); parts.append(f"GS ${g:.2f}/mi")
    if "DAT" in best:
        d = best["DAT"]["ratePerMile"]["median"] + fuel  # DAT is linehaul; add fuel
        rpms.append(d); parts.append(f"DAT ${d:.2f}/mi incl fuel")
    if not rpms:
        return None, "no DAT/Greenscreens best-fit rate"
    rpm = sum(rpms) / len(rpms)
    direct = lp.get("distance") or miles
    extra = max(0.0, miles - direct)
    total = rpm * direct + extra * min(rpm, EXTRA_MILE_RPM)
    extra_note = f" + {extra:,.0f} added mi" if extra else ""
    return total, f"mkt mid ${total:,.0f} ({', '.join(parts)} on {direct:,.0f} direct mi{extra_note})"


def transit_check(load, miles):
    """Returns (hours_available, hours_needed_solo)."""
    hrs = (parse_dt(load["delivery"]) - parse_dt(load["pickup"])).total_seconds() / 3600
    drive = miles / SOLO_MPH
    breaks = max(0, math.ceil(drive / SOLO_DRIVE_HRS) - 1) * SOLO_BREAK_HRS
    stop_time = 1.5 * (len(load["stops"]) + 1)
    return hrs, drive + breaks + stop_time


def vary_ending(rate, key):
    """Round to whole dollars and avoid endings 00/25/50/75; deterministic per trip."""
    r = int(round(rate))
    h = int(hashlib.md5(key.encode()).hexdigest(), 16)
    if r % 100 in BAD_ENDINGS or r % 5 == 0:
        r += (h % 9) + 3
        while r % 100 in BAD_ENDINGS or r % 5 == 0:
            r += 1
    return float(r)


def price_load(load, lane_hist, state_hist, nearby_hist, lp, today):
    d = Decision("quote")
    mode = (load["mode_service"] or "").upper()
    equip = (load["equipment"] or "").upper()
    o_state, f_state = load["origin_state"], load["final_state"]
    f_city, f_zip = load["final_city"].upper(), load["final_zip"]
    stops = load["stops"]
    all_zip3 = {z[:3] for z in stops + [f_zip]}

    # ---- eligibility --------------------------------------------------------
    pickup = parse_dt(load["pickup"])
    if pickup.date() == today:
        return Decision("skip", notes=["same-day pickup"])
    is_air = mode.startswith("AIRFREIGHT")
    is_straight = "24" in equip and ("STRAIGHT" in equip or "BOX" in equip)
    is_cargo_van = "CARGO VAN" in equip
    if is_air and not (is_straight or is_cargo_van):
        return Decision("flag", flags=[f"airfreight on '{load['equipment']}' not quoted (only 24ft straight / cargo van)"])

    # ---- miles: price on real routed miles ------------------------------------
    direct = (lp or {}).get("distance") or 0
    board_mi = load["miles"] or 0
    miles = max(board_mi, direct)
    if not miles:
        return Decision("flag", flags=["no mileage from board or lane pricing"])
    if direct and board_mi > direct * 1.2 and stops:
        d.flags.append(f"stops add {board_mi - direct:,.0f} mi over direct {direct:,.0f} mi (backtracking)")
    d.notes.append(f"{miles:,.0f} routed mi, {len(stops)} extra stop(s)")
    long_haul = miles >= 800

    # ---- base -----------------------------------------------------------------
    mkt, mkt_note = market_midpoint(lp, miles)
    d.notes.append(mkt_note)
    redding = f_city == "REDDING" or bool(all_zip3 & REDDING_ZIP3)
    reno = any(z[:3] in RENO_ZIP3 for z in stops)

    if is_air:
        cost_rpm = 2.0
        cost = max(cost_rpm * miles, 375 if is_straight else 300)
        margin = 1.1 if long_haul else 1.375
        base = cost * margin
        d.notes.append(f"{'24ft straight' if is_straight else 'cargo van'} cost ~${cost:,.0f} x{margin}")
    else:
        hist_avg = recency_weighted_avg(lane_hist[:6])
        if hist_avg and not (redding and reno):
            base = hist_avg
            d.notes.append(f"lane history {len(lane_hist)} loads, recent wtd avg ${hist_avg:,.0f}")
            if mkt and hist_avg < mkt * 0.85:
                base = (hist_avg + mkt) / 2
                d.notes.append("history well below market; blended toward market")
        elif mkt:
            mult = 1.08 if long_haul else (1.2 if miles >= 400 else 1.375)
            base = mkt * mult
            d.notes.append(f"new lane: market x{mult}")
            ref = state_hist if len(state_hist) >= 3 else nearby_hist
            rpm = rpm_avg(ref[:10])
            if rpm:
                d.notes.append(f"{'state' if ref is state_hist else 'nearby'} hist ${rpm:.2f}/mi ({len(ref)} loads)")
                base = 0.65 * base + 0.35 * rpm * miles
            if redding and hist_avg:
                d.notes.append(f"ignored prior Redding history (avg ${hist_avg:,.0f}) — no Reno stop")
        else:
            return Decision("flag", flags=["no lane history and no market data — needs manual price"])

    # ---- adjustments ------------------------------------------------------------
    adds = []
    n_stops = len(stops)
    if n_stops:
        if f_state in WEST_COAST and long_haul:
            per = 300 + 0.08 * miles
            adds.append((n_stops * per, f"elevated CA/WA/OR long-haul stop fee ${per:,.0f} x{n_stops}"))
        else:
            per = 125 if miles < 800 else 175
            adds.append((n_stops * per, f"stop fee ${per} x{n_stops}"))
    if f_state in REMOTE_STATES or redding:
        adds.append((700, "remote lane worst-case carrier cover +$700"))
    if redding and reno:
        adds.append((900 + 0.15 * miles, "Reno stop premium on Redding lane"))
    border = f_city in BORDER_CITIES or bool(all_zip3 & BORDER_ZIP3)
    if border:
        adds.append((350 + 100 * n_stops, "border lane premium"))
    if all_zip3 & NYC_LI_ZIP3:
        adds.append((300, "NYC/Long Island premium"))
    if load["origin_city"].upper().startswith("MARTINSBURG") and pickup.hour < 7:
        adds.append((200, "early-morning Martinsburg pickup"))

    hrs, need = transit_check(load, miles)
    expedited = "EXPEDITED" in mode or "TEAM" in mode
    if hrs < need * 0.9:
        d.flags.append(f"window {hrs:.0f}h < solo need {need:.0f}h — team/expedite")
        expedited = True
    elif hrs < need:
        d.flags.append(f"tight window {hrs:.0f}h vs ~{need:.0f}h solo")
    elif hrs > need * 3 and hrs > 96:
        d.flags.append(f"unusually long window {hrs:.0f}h vs {need:.0f}h needed")
    if expedited:
        adds.append((min(1000, 300 + 0.35 * miles), "expedited/team premium"))

    rate = base + sum(a for a, _ in adds)
    d.notes += [n for _, n in adds]

    mult = 1.0
    if pickup.weekday() >= 5 and o_state in SOUTH:
        mult = 0.95
        d.notes.append("weekend out of WV/VA/South: tighter x0.95")
    elif o_state in ("IL", "WI"):
        mult = 0.97
        d.notes.append("IL/WI origin: slightly tighter x0.97")
    rate *= mult

    rate = vary_ending(rate, load["trip_id"])
    rpm = rate / miles
    if rpm < 1.3 or rpm > 15:
        return Decision("flag", notes=d.notes, flags=d.flags + [f"computed ${rate:,.0f} (${rpm:.2f}/mi) outside sanity range — not saved"])
    d.rate = rate
    return d
