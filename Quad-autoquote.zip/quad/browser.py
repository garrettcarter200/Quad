"""Shared Playwright browser setup.

The sandbox routes HTTPS through an egress proxy with its own CA, which
Chromium does not trust, so certificate errors are ignored here.
"""
from contextlib import contextmanager

from playwright.sync_api import sync_playwright


@contextmanager
def browser_context():
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        ctx = browser.new_context(
            ignore_https_errors=True,
            viewport={"width": 1700, "height": 1100},
            timezone_id="America/New_York",
        )
        try:
            yield ctx
        finally:
            browser.close()
