class StopRun(Exception):
    """Abort the run and report a single short message (login/MFA/missing creds)."""
