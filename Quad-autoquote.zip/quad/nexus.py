"""Nexus (TILT) GraphQL client: login via SSO in the browser, then call the API."""
import os
import time

import requests
import urllib3

from .errors import StopRun

urllib3.disable_warnings()  # sandbox egress proxy re-signs TLS

NEXUS_URL = "https://nexus.tiltgroup.com"
API = f"{NEXUS_URL}/api/graphql"
QUAD_CLIENT_ID = 2217


class Nexus:
    def __init__(self, token):
        self.token = token

    @classmethod
    def login(cls, ctx):
        user, pw = os.environ.get("NEXUS_USERNAME"), os.environ.get("NEXUS_PASSWORD")
        if not user or not pw:
            raise StopRun("NEXUS_USERNAME / NEXUS_PASSWORD not set; add them to the environment.")
        page = ctx.new_page()
        tok = {}
        page.on("request", lambda r: tok.setdefault("a", r.headers.get("authorization"))
                if "/api/graphql" in r.url and r.headers.get("authorization") else None)
        page.goto(NEXUS_URL, wait_until="networkidle")
        if "sso.tiltgroup.com" in page.url:
            page.fill("#username", user)
            page.fill("#password", pw)
            page.click("#kc-login")
            page.wait_for_load_state("networkidle")
        if "sso.tiltgroup.com" in page.url:
            body = page.inner_text("body").lower()
            if any(k in body for k in ("one-time", "otp", "authenticator", "captcha", "verification")):
                raise StopRun("Nexus SSO asked for MFA/captcha; complete it manually or exempt this account.")
            raise StopRun("Nexus login failed; check NEXUS_USERNAME / NEXUS_PASSWORD.")
        for _ in range(20):
            if tok.get("a"):
                break
            page.wait_for_timeout(500)
        page.close()
        if not tok.get("a"):
            raise StopRun("Nexus login succeeded but no API token was captured.")
        return cls(tok["a"])

    def gq(self, query, variables=None):
        r = requests.post(API, json={"query": query, "variables": variables or {}},
                          headers={"Authorization": self.token}, verify=False, timeout=60)
        r.raise_for_status()
        d = r.json()
        if d.get("errors"):
            raise RuntimeError(f"Nexus API error: {d['errors'][0].get('message')}")
        return d["data"]

    # ---- Quad shipment history -------------------------------------------------
    HISTORY_Q = """query($w:QueryLoadsWhereWhereConditions,$n:Int!){
      loads(first:$n,page:1,where:$w,hasClient:{column:ID,operator:EQ,value:[%d]},
            orderBy:[{column:ORIGIN_APPOINTMENT_AT_UTC,order:DESC}]){
        data{ id status customerTotalRate customer_miles total_stops equipment_type{name}
              origin{place region_code postcode appointment_at}
              destination{place region_code postcode appointment_at} } } }""" % QUAD_CLIENT_ID

    def history(self, where, n=25):
        w = {"AND": where + [{"column": "CUSTOMER_TOTAL_RATE", "operator": "GT", "value": 0}]}
        rows = self.gq(self.HISTORY_Q, {"w": w, "n": n})["loads"]["data"]
        return [r for r in rows if r.get("origin") and r.get("destination")
                and r.get("customerTotalRate") and (r.get("origin") or {}).get("appointment_at")]

    def dest_state_history(self, o_state, d_state):
        return self.history([
            {"column": "ORIGIN_REGION_CODE", "operator": "EQ", "value": o_state},
            {"column": "DESTINATION_REGION_CODE", "operator": "EQ", "value": d_state},
        ], n=100)

    def nearby_history(self, o_state, d_zip):
        """Nearby towns = same 3-digit destination ZIP prefix."""
        return self.history([
            {"column": "ORIGIN_REGION_CODE", "operator": "EQ", "value": o_state},
            {"column": "DESTINATION_POSTCODE", "operator": "LIKE", "value": f"{d_zip[:3]}%"},
        ])

    # ---- Lane Pricing (DAT + Greenscreens) ---------------------------------------
    def lane_pricing(self, o_city, o_state, o_zip, d_city, d_state, d_zip, pickup_iso):
        m = """mutation($i:LanePricingInput!){initiateLanePricing(input:$i){id}}"""
        lid = self.gq(m, {"i": {
            "originCity": o_city, "originState": o_state, "originZip": o_zip, "originCountry": "US",
            "destinationCity": d_city, "destinationState": d_state, "destinationZip": d_zip,
            "destinationCountry": "US", "equipmentType": "VAN", "pickupDate": pickup_iso,
        }})["initiateLanePricing"]["id"]
        q = """query($id:Int!){lanePricing(id:$id){id status distance fuelRate
               rates{source window areaType confidence mileage ratePerMile{min median max}}}}"""
        for _ in range(30):
            lp = self.gq(q, {"id": lid})["lanePricing"]
            if lp["status"] in ("COMPLETED", "FAILED"):
                return lp
            time.sleep(3)
        return lp
