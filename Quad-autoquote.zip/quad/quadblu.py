"""QuadBlu vendor portal: login, read spot board, save a rate."""
import os
import re

from .errors import StopRun

LOGIN_URL = "https://quadblu.qg.com/site/external/login"
BOARD_URL = "https://quadblu.qg.com/site/vendorPortal/tab/spotQuoteLoadsExternal"
USERNAME = "garrett.carter@holstonfreight.com"
ACCOUNT = "HD SHIPPING SOLUTIONS LLC"

COLUMNS = [
    "visibility", "notes", "trip_id", "tanker", "pickup", "origin_city", "origin_state",
    "origin_zip", "stop1_zip", "stop2_zip", "stop3_zip", "delivery", "final_city",
    "final_state", "final_zip", "miles", "weight", "counter_price", "mode_service",
    "load_id", "special_needs", "equipment",
]


def rate_input_id(trip_id):
    return f"BtnAssignQuote{trip_id}PriceCurrencyInputNumericInput"


def parse_money(s):
    s = (s or "").replace("$", "").replace(",", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


def login(page):
    pw = os.environ.get("QUADBLU_PASSWORD")
    if not pw:
        raise StopRun("QUADBLU_PASSWORD is not set; add it to the environment.")
    page.goto(LOGIN_URL, wait_until="networkidle")
    if "b2clogin.com" in page.url:
        page.fill("#logonIdentifier", USERNAME)
        page.fill("#password", pw)
        page.keyboard.press("Enter")
        try:
            page.wait_for_url(re.compile(r"https://quadblu\.qg\.com/"), timeout=30000)
        except Exception:
            txt = page.inner_text("body")[:400].lower()
            if any(k in txt for k in ("verification", "code", "captcha", "verify")):
                raise StopRun("QuadBlu asked for MFA/captcha; complete it manually or disable it for this account.")
            raise StopRun("QuadBlu login failed; check QUADBLU_PASSWORD for garrett.carter@holstonfreight.com.")


def load_board(page):
    """Open (refresh) the spot board, set 100 rows, return list of row dicts."""
    page.goto(BOARD_URL, wait_until="networkidle")
    page.wait_for_selector(".rt-tr-group", timeout=45000)
    if ACCOUNT not in page.inner_text("body"):
        raise StopRun(f"QuadBlu account selector is not {ACCOUNT}; check the portal.")
    page.select_option("select[aria-label='rows per page']", label="100 rows")
    page.wait_for_timeout(2500)

    rows = []
    while True:
        rows.extend(_read_rows(page))
        nxt = page.locator("button.-btn", has_text="Next")
        if nxt.count() and nxt.first.is_enabled():
            nxt.first.click()
            page.wait_for_timeout(2500)
        else:
            break
    return rows


def _read_rows(page):
    raw = page.eval_on_selector_all(
        ".rt-tbody .rt-tr-group",
        "gs => gs.map(g => Array.from(g.querySelectorAll('.rt-td')).map(td => td.innerText.trim()))",
    )
    out = []
    for cells in raw:
        if len(cells) < len(COLUMNS) or not re.match(r"^Q\d+", cells[2] or ""):
            continue
        r = dict(zip(COLUMNS, cells[: len(COLUMNS)]))
        loc = page.locator(f"#{rate_input_id(r['trip_id'])}")
        r["current_rate"] = parse_money(loc.input_value()) if loc.count() else None
        r["miles"] = parse_money(r["miles"])
        r["weight"] = parse_money(r["weight"])
        r["stops"] = [z for z in (r["stop1_zip"], r["stop2_zip"], r["stop3_zip"]) if z]
        out.append(r)
    return out


def save_rate(page, trip_id, rate):
    """Type the rate, Save, and verify Revoke is enabled. Returns (ok, message).

    Re-checks the rate is still 0.00 immediately before typing so a load quoted by
    someone else (or a prior run) is never modified.
    """
    inp = page.locator(f"#{rate_input_id(trip_id)}")
    if not inp.count():
        return False, "rate input not found"
    current = parse_money(inp.input_value())
    if current not in (0.0, None):
        return False, f"already quoted ({current:,.2f}); not modified"

    row = inp.locator("xpath=ancestor::div[contains(@class,'form-group-sm')][1]")
    inp.click()
    inp.press("Control+a")
    inp.type(f"{rate:.2f}", delay=30)
    inp.press("Tab")  # expiration auto-fills on blur
    page.wait_for_timeout(800)

    save = row.locator("button", has_text="Save")
    if not save.is_enabled():
        return False, "Save button stayed disabled after typing rate"
    save.click()
    page.wait_for_timeout(3000)

    revoke = row.locator("button", has_text="Revoke")
    saved = parse_money(inp.input_value())
    if not (revoke.count() and revoke.is_enabled()):
        return False, "saved but Revoke not enabled; verify manually"
    if saved is None or abs(saved - rate) > 0.5:
        return False, f"rate shows {saved} after save; verify manually"
    return True, "saved; Revoke enabled"
