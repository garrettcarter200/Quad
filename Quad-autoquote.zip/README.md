# Quad

Automated spot quoting for Quad Graphics loads on the QuadBlu vendor board
(account HD SHIPPING SOLUTIONS LLC), priced with Nexus history + Lane Pricing
(DAT + Greenscreens) for customer QUAD GRAPHICS INC (client 2217).

## Setup (once per fresh environment)

```bash
./setup.sh   # pip deps + Playwright Chromium
```

Required environment variables (never commit them): `NEXUS_USERNAME`,
`NEXUS_PASSWORD`, `QUADBLU_PASSWORD`. QuadBlu username is
garrett.carter@holstonfreight.com.

## Run

```bash
python3 -m quad.run              # live: quotes every 0.00 load and saves it
python3 -m quad.run --dry-run    # same, but saves nothing
python3 -m quad.run --price-all  # test: price every load on the board, saves nothing
```

Each run: log in to QuadBlu, refresh the board, set 100 rows, then pick the loads
whose rate is 0.00. If there are none, it prints `No new loads to quote` and exits
without logging in to Nexus. Otherwise, for each load it:

1. Skips same-day pickups (America/New_York) and flags airfreight on equipment
   other than a 24 ft straight truck or cargo van.
2. Pulls Quad history from Nexus (exact lane, destination state, and nearby
   3-digit destination ZIP), weighting the most recent loads highest. Runs Lane
   Pricing for DAT + Greenscreens.
3. Prices the load with `quad/pricing.py`, using the routed board miles, the
   transit check, and the stop, remote, border, NYC/LI, Redding/Reno, and
   CA/WA/OR stop rules.
4. Re-checks that the rate still reads 0.00, types the rate, clicks Save, and
   confirms Revoke is enabled. It never changes a load that is already quoted.
5. Prints a markdown summary table showing what was quoted, skipped, or flagged.

Exit codes: `0` ok, `2` the run stopped on a login, MFA, or credential problem.
In that case the one-line reason is printed.
